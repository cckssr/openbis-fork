def validate(entity, isNew):
  pass
 